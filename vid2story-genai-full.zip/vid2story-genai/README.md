# Video-to-Story Generator

Upload a short video and generate a story using Whisper, BLIP2, and GPT.
