import os
from PIL import Image
import torch
from transformers import Blip2Processor, Blip2ForConditionalGeneration

device = "cuda" if torch.cuda.is_available() else "cpu"
processor = Blip2Processor.from_pretrained("Salesforce/blip2-opt-2.7b")
model = Blip2ForConditionalGeneration.from_pretrained("Salesforce/blip2-opt-2.7b").to(device)

def generate_captions(frames_dir='static/frames'):
    captions = []
    for fname in sorted(os.listdir(frames_dir)):
        if fname.endswith(".jpg"):
            image = Image.open(os.path.join(frames_dir, fname)).convert("RGB")
            inputs = processor(images=image, return_tensors="pt").to(device)
            output = model.generate(**inputs, max_new_tokens=20)
            caption = processor.decode(output[0], skip_special_tokens=True)
            captions.append(caption)
    return captions
